
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, DetectionStatus, GroundingSource } from "../types";

export const analyzeNews = async (newsText: string): Promise<AnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const prompt = `
    You are an ensemble news verification system combining a BERT-style semantic classifier and a Factual Verification engine.
    
    TASK:
    1. Perform a Semantic Analysis (BERT-style): Look for clickbait, emotional manipulation, sensationalism, and syntactic patterns typical of misinformation.
    2. Perform a Factual Verification: Use Google Search to verify the actual claims in the text.
    
    News Text to analyze: "${newsText}"
    
    Return a structured JSON response.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            verdict: { type: Type.STRING, description: "REAL, FAKE, or MISLEADING" },
            confidence: { type: Type.NUMBER },
            semanticIntegrityScore: { type: Type.NUMBER, description: "Score from 0-100 representing linguistic reliability" },
            factualAccuracyScore: { type: Type.NUMBER, description: "Score from 0-100 representing factual grounding" },
            explanation: { type: Type.STRING },
            linguisticMarkers: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "List of markers like 'Sensationalism', 'Clickbait', 'Neutral Tone', etc."
            }
          },
          required: ["verdict", "confidence", "semanticIntegrityScore", "factualAccuracyScore", "explanation", "linguisticMarkers"]
        }
      },
    });

    const resultData = JSON.parse(response.text || "{}");
    const candidates = response.candidates?.[0];
    const groundingChunks = candidates?.groundingMetadata?.groundingChunks || [];
    
    const sources: GroundingSource[] = groundingChunks
      .filter(chunk => chunk.web)
      .map(chunk => ({
        title: chunk.web?.title || 'External Source',
        uri: chunk.web?.uri || ''
      }))
      .filter(source => source.uri !== '');

    let status = DetectionStatus.MISLEADING;
    const verdict = resultData.verdict.toUpperCase();
    if (verdict === 'REAL') status = DetectionStatus.REAL;
    if (verdict === 'FAKE') status = DetectionStatus.FAKE;

    return {
      status,
      explanation: resultData.explanation,
      confidence: resultData.confidence,
      semanticScore: resultData.semanticIntegrityScore,
      factualScore: resultData.factualAccuracyScore,
      linguisticMarkers: resultData.linguisticMarkers,
      sources: sources.slice(0, 5)
    };
  } catch (error) {
    console.error("Ensemble Analysis Error:", error);
    throw new Error("Failed to perform dual-engine verification.");
  }
};
